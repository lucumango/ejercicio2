using System.ComponentModel.DataAnnotations;

namespace ScreeningBff.Models;

public class Vendor
{
    [Key]
    public Guid Id { get; set; }
    
    [Required]
    [MaxLength(200)]
    public string RazonSocial { get; set; } = string.Empty;
    
    [Required]
    [MaxLength(100)]
    public string NombreComercial { get; set; } = string.Empty;
    
    [Required]
    [StringLength(11, MinimumLength = 11)]
    public string Ruc { get; set; } = string.Empty;
    
    [Required]
    public string Telefono { get; set; } = string.Empty;
    
    [Required]
    public string TipoTelefono { get; set; } = "fijo";
    
    [Required]
    [EmailAddress]
    public string Email { get; set; } = string.Empty;
    
    [Required]
    public string TipoEmail { get; set; } = "corporativo";
    
    [Url]
    public string? SitioWeb { get; set; }
    
    [Required]
    public string Direccion { get; set; } = string.Empty;
    
    [Required]
    [StringLength(2)]
    public string Pais { get; set; } = "PE";
    
    [Required]
    [Range(0, double.MaxValue)]
    public decimal FacturacionAnual { get; set; }
    
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}