namespace ScreeningBff.Models;

public class ScreeningRequestDto
{
    public string EntityName { get; set; } = "";
    public List<string> Sources { get; set; } = new();
    public bool UseBrowserAgent { get; set; } = true;
}
