using System.Net.Http.Json;
using Microsoft.Extensions.Configuration;

namespace ScreeningBff.Services;

public class ScreeningClient
{
    private readonly HttpClient _http;
    private readonly IConfiguration _config;

    public ScreeningClient(HttpClient http, IConfiguration config)
    {
        _http = http;
        _config = config;
    }

    public async Task<string> SearchRawAsync(object req, CancellationToken ct)
    {
        var baseUrl = _config["ScreeningApi:BaseUrl"];
        var apiKey  = _config["ScreeningApi:ApiKey"];

        if (string.IsNullOrEmpty(apiKey))
            throw new Exception("Missing ScreeningApi:ApiKey");

        var request = new HttpRequestMessage(
            HttpMethod.Post,
            $"{baseUrl}/v1/screening/search"
        );

        request.Headers.Add("x-api-key", apiKey);

        request.Content = JsonContent.Create(req);

        var response = await _http.SendAsync(request, ct);
        var body = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)
            throw new Exception($"Upstream {(int)response.StatusCode}: {body}");

        return body;
    }
}
