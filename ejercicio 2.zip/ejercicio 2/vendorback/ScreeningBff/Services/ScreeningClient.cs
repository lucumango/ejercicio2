using System.Net.Http.Json;

namespace ScreeningBff.Services;

public class ScreeningClient
{
    private readonly HttpClient _http;
    private readonly IConfiguration _cfg;

    public ScreeningClient(HttpClient http, IConfiguration cfg)
    {
        _http = http;
        _cfg = cfg;
    }

    public async Task<string> SearchRawAsync(object req, CancellationToken ct)
    {
        var apiKey = _cfg["Screening:ApiKey"];

        using var msg = new HttpRequestMessage(HttpMethod.Post, "/v1/screening/search");
        msg.Headers.Add("x-api-key", apiKey);
        msg.Content = JsonContent.Create(req);

        var res = await _http.SendAsync(msg, ct);
        var body = await res.Content.ReadAsStringAsync(ct);

        if (!res.IsSuccessStatusCode)
            throw new Exception($"FastAPI error {(int)res.StatusCode}: {body}");

        return body;
    }
}
