using Microsoft.EntityFrameworkCore;
using ScreeningBff.Data;
using ScreeningBff.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// SQL Server
builder.Services.AddDbContext<VendorDbContext>(options =>
{
    var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
    options.UseSqlServer(connectionString, sqlOptions => 
    {
        sqlOptions.EnableRetryOnFailure(
            maxRetryCount: 5,
            maxRetryDelay: TimeSpan.FromSeconds(10),
            errorNumbersToAdd: null
        );
        sqlOptions.CommandTimeout(30);
    });
    
    // Logging detallado en desarrollo
    if (builder.Environment.IsDevelopment())
    {
        options.EnableSensitiveDataLogging();
        options.EnableDetailedErrors();
    }
});

// Screening Client
builder.Services.AddHttpClient<ScreeningClient>(client =>
{
    client.BaseAddress = new Uri(builder.Configuration["FastApi:BaseUrl"] ?? "http://localhost:8000");
    client.Timeout = TimeSpan.FromSeconds(60);
});

// CORS - Actualizado para puerto 8080
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins(
                "http://localhost:8080",
                "http://localhost:5173",
                "http://localhost:5174"
            )
            .AllowAnyMethod()
            .AllowAnyHeader()
            .AllowCredentials();
    });
});

var app = builder.Build();

// Migrate database on startup con mejor manejo de errores
Console.WriteLine("🔄 Checking database connection...");
try
{
    using var scope = app.Services.CreateScope();
    var db = scope.ServiceProvider.GetRequiredService<VendorDbContext>();
    
    // Test connection
    if (await db.Database.CanConnectAsync())
    {
        Console.WriteLine("✅ Database connection successful");
        
        // Apply migrations
        var pendingMigrations = await db.Database.GetPendingMigrationsAsync();
        if (pendingMigrations.Any())
        {
            Console.WriteLine($"📊 Applying {pendingMigrations.Count()} pending migrations...");
            await db.Database.MigrateAsync();
            Console.WriteLine("✅ Migrations applied successfully");
        }
        else
        {
            Console.WriteLine("✅ Database is up to date");
        }
    }
    else
    {
        Console.WriteLine("⚠️ Cannot connect to database. Make sure SQL Server is running.");
        Console.WriteLine("   Docker: docker-compose up -d");
    }
}
catch (Exception ex)
{
    Console.WriteLine($"❌ Database error: {ex.Message}");
    Console.WriteLine("⚠️ API will start but database operations will fail.");
    Console.WriteLine("   Connection string: " + builder.Configuration.GetConnectionString("DefaultConnection"));
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// IMPORTANTE: CORS debe ir ANTES de MapControllers
app.UseCors("AllowFrontend");
app.MapControllers();

Console.WriteLine("🚀 API running on http://localhost:5099");
Console.WriteLine("📊 Swagger available at http://localhost:5099/swagger");

app.Run();