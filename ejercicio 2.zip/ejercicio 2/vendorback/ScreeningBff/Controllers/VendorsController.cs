using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ScreeningBff.Data;
using ScreeningBff.Models;

namespace ScreeningBff.Controllers;

[ApiController]
[Route("api/[controller]")]
public class VendorsController : ControllerBase
{
    private readonly VendorDbContext _context;
    private readonly ILogger<VendorsController> _logger;

    public VendorsController(VendorDbContext context, ILogger<VendorsController> logger)
    {
        _context = context;
        _logger = logger;
    }

    // GET: api/vendors
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Vendor>>> GetVendors()
    {
        try
        {
            _logger.LogInformation("Fetching all vendors");
            
            var vendors = await _context.Vendors
                .OrderByDescending(v => v.CreatedAt)
                .ToListAsync();
            
            _logger.LogInformation("Successfully fetched {Count} vendors", vendors.Count);
            return Ok(vendors);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al obtener proveedores");
            return StatusCode(500, new 
            { 
                error = "Error al obtener proveedores",
                detail = ex.Message,
                type = ex.GetType().Name
            });
        }
    }

    // GET: api/vendors/{id}
    [HttpGet("{id}")]
    public async Task<ActionResult<Vendor>> GetVendor(Guid id)
    {
        try
        {
            var vendor = await _context.Vendors.FindAsync(id);
            
            if (vendor == null)
            {
                _logger.LogWarning("Vendor {Id} not found", id);
                return NotFound(new { error = "Proveedor no encontrado" });
            }
            
            return Ok(vendor);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al obtener proveedor {Id}", id);
            return StatusCode(500, new 
            { 
                error = "Error al obtener proveedor",
                detail = ex.Message 
            });
        }
    }

    // POST: api/vendors
    [HttpPost]
    public async Task<ActionResult<Vendor>> CreateVendor([FromBody] Vendor vendor)
    {
        try
        {
            _logger.LogInformation("Creating vendor: {RazonSocial}", vendor.RazonSocial);
            
            // Verificar RUC duplicado
            if (await _context.Vendors.AnyAsync(v => v.Ruc == vendor.Ruc))
            {
                _logger.LogWarning("Duplicate RUC: {Ruc}", vendor.Ruc);
                return BadRequest(new { error = "Ya existe un proveedor con ese RUC" });
            }

            vendor.Id = Guid.NewGuid();
            vendor.CreatedAt = DateTime.UtcNow;
            vendor.UpdatedAt = DateTime.UtcNow;

            _context.Vendors.Add(vendor);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Vendor created successfully: {Id}", vendor.Id);
            return CreatedAtAction(nameof(GetVendor), new { id = vendor.Id }, vendor);
        }
        catch (DbUpdateException ex)
        {
            _logger.LogError(ex, "Database error creating vendor");
            return StatusCode(500, new 
            { 
                error = "Error de base de datos al crear proveedor",
                detail = ex.InnerException?.Message ?? ex.Message
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating vendor");
            return StatusCode(500, new 
            { 
                error = "Error al crear proveedor",
                detail = ex.Message 
            });
        }
    }

    // PUT: api/vendors/{id}
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateVendor(Guid id, [FromBody] Vendor vendor)
    {
        if (id != vendor.Id)
        {
            _logger.LogWarning("ID mismatch: {PathId} vs {BodyId}", id, vendor.Id);
            return BadRequest(new { error = "ID no coincide" });
        }

        try
        {
            var existing = await _context.Vendors.FindAsync(id);
            if (existing == null)
            {
                _logger.LogWarning("Vendor {Id} not found for update", id);
                return NotFound(new { error = "Proveedor no encontrado" });
            }

            // Verificar RUC duplicado (excluyendo el actual)
            if (await _context.Vendors.AnyAsync(v => v.Ruc == vendor.Ruc && v.Id != id))
            {
                _logger.LogWarning("Duplicate RUC on update: {Ruc}", vendor.Ruc);
                return BadRequest(new { error = "Ya existe otro proveedor con ese RUC" });
            }

            existing.RazonSocial = vendor.RazonSocial;
            existing.NombreComercial = vendor.NombreComercial;
            existing.Ruc = vendor.Ruc;
            existing.Telefono = vendor.Telefono;
            existing.TipoTelefono = vendor.TipoTelefono;
            existing.Email = vendor.Email;
            existing.TipoEmail = vendor.TipoEmail;
            existing.SitioWeb = vendor.SitioWeb;
            existing.Direccion = vendor.Direccion;
            existing.Pais = vendor.Pais;
            existing.FacturacionAnual = vendor.FacturacionAnual;
            existing.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            
            _logger.LogInformation("Vendor {Id} updated successfully", id);
            return Ok(existing);
        }
        catch (DbUpdateException ex)
        {
            _logger.LogError(ex, "Database error updating vendor {Id}", id);
            return StatusCode(500, new 
            { 
                error = "Error de base de datos al actualizar proveedor",
                detail = ex.InnerException?.Message ?? ex.Message
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating vendor {Id}", id);
            return StatusCode(500, new 
            { 
                error = "Error al actualizar proveedor",
                detail = ex.Message 
            });
        }
    }

    // DELETE: api/vendors/{id}
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteVendor(Guid id)
    {
        try
        {
            var vendor = await _context.Vendors.FindAsync(id);
            if (vendor == null)
            {
                _logger.LogWarning("Vendor {Id} not found for deletion", id);
                return NotFound(new { error = "Proveedor no encontrado" });
            }

            _context.Vendors.Remove(vendor);
            await _context.SaveChangesAsync();
            
            _logger.LogInformation("Vendor {Id} deleted successfully", id);
            return NoContent();
        }
        catch (DbUpdateException ex)
        {
            _logger.LogError(ex, "Database error deleting vendor {Id}", id);
            return StatusCode(500, new 
            { 
                error = "Error de base de datos al eliminar proveedor",
                detail = ex.InnerException?.Message ?? ex.Message
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting vendor {Id}", id);
            return StatusCode(500, new 
            { 
                error = "Error al eliminar proveedor",
                detail = ex.Message 
            });
        }
    }
}