using Microsoft.AspNetCore.Mvc;
using ScreeningBff.Services;

namespace ScreeningBff.Controllers;

[ApiController]
[Route("api/screening")]
public class ScreeningController : ControllerBase
{
    private readonly ScreeningClient _client;

    public ScreeningController(ScreeningClient client)
    {
        _client = client;
    }

    [HttpPost("search")]
public async Task<IActionResult> Search([FromBody] object req, CancellationToken ct)
{
    try
    {
        var json = await _client.SearchRawAsync(req, ct);
        return Content(json, "application/json");
    }
    catch (TaskCanceledException)
    {
        return StatusCode(504, new {
            error = "SCREENING_TIMEOUT",
            message = "El screening demoró demasiado. Intenta de nuevo o reduce fuentes / desactiva browser agent."
        });
    }
    catch (Exception ex)
    {
        return StatusCode(502, new {
            error = "SCREENING_UPSTREAM_ERROR",
            message = ex.Message
        });
    }
}

}
