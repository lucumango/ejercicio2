using Microsoft.EntityFrameworkCore;
using ScreeningBff.Models;

namespace ScreeningBff.Data;

public class VendorDbContext : DbContext
{
    public VendorDbContext(DbContextOptions<VendorDbContext> options) : base(options) { }

    public DbSet<Vendor> Vendors => Set<Vendor>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Vendor>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.Ruc).IsUnique();
            entity.Property(e => e.FacturacionAnual).HasColumnType("decimal(18,2)");
        });
    }
}