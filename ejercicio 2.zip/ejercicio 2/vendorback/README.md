

# Ejercicio 2 — Backend

## Sistema de Debida Diligencia de Proveedores (Screening + Inventario)

## 1. Objetivo

Desarrollar el **backend** de una aplicación web que permita **administrar un inventario de proveedores** y realizar **screening automático contra listas de alto riesgo**, integrando el **API de scraping del Ejercicio 1**.

El backend actúa como una **capa BFF (Backend for Frontend)**, centralizando:

* Validaciones
* Manejo de errores
* Orquestación de llamadas al motor de screening
* Exposición de un REST API consumido por el frontend SPA

---

## 2. Stack Tecnológico

| Capa                | Tecnología                            |
| ------------------- | ------------------------------------- |
| Lenguaje            | C#                                    |
| Framework           | .NET 8 / ASP.NET Core                 |
| Tipo API            | REST                                  |
| Servidor            | Kestrel                               |
| Patrón              | Controller + Service (BFF)            |
| Integración externa | Screening API (Ejercicio 1 – FastAPI) |

---

## 3. Arquitectura General

```text
[ React SPA ]
      |
      | HTTP (JSON)
      v
[ .NET Screening BFF ]
      |
      | HTTP (JSON)
      v
[ High-Risk Screening API ]
(OFAC / WorldBank / ICIJ)
```

### Rol del Backend (.NET)

* Recibe solicitudes del frontend
* Valida el request
* Reenvía la solicitud al motor de screening
* Devuelve la respuesta **sin exponer la complejidad del scraping**
* Maneja timeouts y errores de fuentes externas

---

## 4. Endpoints Implementados

### 4.1 Screening de Proveedores

**POST**

```
/api/screening/search
```

#### Request

```json
{
  "entityName": "SIGNUM",
  "sources": ["WORLDBANK", "OFAC"],
  "useBrowserAgent": true
}
```

#### Response (ejemplo)

```json
{
  "query": {
    "entityName": "SIGNUM",
    "sourcesRequested": ["OFAC", "WORLDBANK"],
    "useBrowserAgent": true
  },
  "summary": {
    "hitsTotal": 2,
    "hitsBySource": {
      "OFAC": 1,
      "WORLDBANK": 1
    },
    "status": "POSSIBLE_MATCH"
  },
  "results": [
    {
      "source": "OFAC",
      "extractionMethod": "browser_agent",
      "match": {
        "normalizedQuery": "SIGNUM",
        "normalizedHitName": "SIGNUM HOLDINGS",
        "fuzzyScore": 88,
        "level": "POSSIBLE_MATCH"
      },
      "attributes": { "...": "..." },
      "evidence": {
        "sourceUrl": "https://sanctionssearch.ofac.treas.gov",
        "retrievedAt": "2025-01-01T10:00:00Z"
      }
    }
  ],
  "errors": [],
  "requestId": "uuid"
}
```

---

## 5. Controlador Principal

```csharp
[ApiController]
[Route("api/screening")]
public class ScreeningController : ControllerBase
```

### Responsabilidades

* Recibir el request desde el frontend
* Enviar el payload al **ScreeningClient**
* Retornar la respuesta cruda en formato JSON
* Manejar errores de red y timeouts

---

## 6. Manejo de Errores

| Caso                           | Código                      |
| ------------------------------ | --------------------------- |
| Timeout del motor de screening | `504 Gateway Timeout`       |
| Error upstream (scraping)      | `502 Bad Gateway`           |
| Error inesperado               | `500 Internal Server Error` |

Ejemplo:

```json
{
  "error": "SCREENING_TIMEOUT",
  "message": "El screening demoró demasiado. Intenta de nuevo o reduce fuentes."
}
```

---

## 7. Importancia del Backend como BFF

El backend cumple un rol clave:

* Evita que el frontend consuma directamente servicios de scraping
* Centraliza políticas de error y resiliencia
* Permite cambiar el motor de screening sin afectar la SPA
* Facilita la evolución futura (auth, auditoría, persistencia)

---

## 8. Ejecución Local

### Requisitos

* .NET SDK 8+
* Motor de Screening (Ejercicio 1) ejecutándose

### Ejecutar

```bash
dotnet restore
dotnet run
```

Por defecto:

```
http://localhost:5099
```

---

## 9. Entregables (Ejercicio 2 – Backend)

* Código fuente en **ZIP**
* Proyecto .NET funcional
* Endpoint `/api/screening/search`
* Integración con el API de screening del Ejercicio 1
* Documentación (este README)

---

## 10. Mejoras Futuras

* Autenticación JWT
* Persistencia en SQL Server
* Auditoría de screenings
* Cache de resultados
* Rate limiting a nivel BFF

---

## 11. Conclusión

Este backend implementa una **capa intermedia robusta** que permite integrar procesos de **debida diligencia automatizada**, cumpliendo los requisitos del ejercicio y dejando la base preparada para una aplicación empresarial real.
